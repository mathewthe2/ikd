import Cocoa
import SwiftUI

class SearchWindow: NSWindow {

    override var canBecomeKey: Bool {
        true
    }

    override var canBecomeMain: Bool {
        true
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {

    var window: SearchWindow!

    private let shortcut = GlobalShortcut()

    private let compactHeight: CGFloat = 72
    private let expandedHeight: CGFloat = 420
    private let windowWidth: CGFloat = 680

    func applicationDidFinishLaunching(
        _ notification: Notification
    ) {

        createWindow()

        shortcut.onShortcut = { [weak self] in
            self?.toggleWindow()
        }

        shortcut.register()
    }

    private func createWindow() {

        let contentView = ContentView(
            onQueryChanged: { [weak self] query in
                self?.updateWindowSize(
                    hasResults: !query.isEmpty
                )
            }
        )

        window = SearchWindow(
            contentRect: NSRect(
                x: 0,
                y: 0,
                width: windowWidth,
                height: compactHeight
            ),
            styleMask: [
                .borderless
            ],
            backing: .buffered,
            defer: false
        )

        window.isOpaque = false
        window.backgroundColor = .clear

        window.level = .floating

        window.collectionBehavior = [
            .canJoinAllSpaces,
            .fullScreenAuxiliary
        ]

        window.hasShadow = true
        window.isReleasedWhenClosed = false

        window.contentView = NSHostingView(
            rootView: contentView
        )

        positionWindow(
            height: compactHeight
        )

        window.orderOut(nil)
    }

    // MARK: - Show / Hide

    private func toggleWindow() {

        if window.isVisible {
            hideWindow()
        } else {
            showWindow()
        }
    }

    private func showWindow() {

        positionWindow(
            height: compactHeight
        )

        NSApp.activate(
            ignoringOtherApps: true
        )

        window.alphaValue = 0

        window.orderFrontRegardless()

        // This now works because SearchWindow
        // overrides canBecomeKey.
        window.makeKey()

        NSAnimationContext.runAnimationGroup { context in

            context.duration = 0.18

            context.timingFunction =
                CAMediaTimingFunction(
                    name: .easeOut
                )

            window.animator().alphaValue = 1
        }
    }

    private func hideWindow() {

        NSAnimationContext.runAnimationGroup(
            { context in

                context.duration = 0.12

                context.timingFunction =
                    CAMediaTimingFunction(
                        name: .easeIn
                    )

                window.animator().alphaValue = 0
            },
            completionHandler: {

                self.window.orderOut(nil)
            }
        )
    }

    // MARK: - Resize

    private func updateWindowSize(
        hasResults: Bool
    ) {

        let height = hasResults
            ? expandedHeight
            : compactHeight

        positionWindow(
            height: height,
            animated: true
        )
    }

    private func positionWindow(
        height: CGFloat,
        animated: Bool = false
    ) {

        guard let screen = NSScreen.main else {
            return
        }

        let screenFrame = screen.visibleFrame

        let x =
            screenFrame.midX
            - windowWidth / 2

        let y =
            screenFrame.maxY
            - height
            - 120

        let frame = NSRect(
            x: x,
            y: y,
            width: windowWidth,
            height: height
        )

        if animated {

            window.animator().setFrame(
                frame,
                display: true
            )

        } else {

            window.setFrame(
                frame,
                display: true
            )
        }
    }

    func applicationWillTerminate(
        _ notification: Notification
    ) {
        shortcut.unregister()
    }
}
